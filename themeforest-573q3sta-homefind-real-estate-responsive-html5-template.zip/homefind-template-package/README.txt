PSD files were excluded from the main package to reduce the package file size. 

You can create a support ticket on our support site in case you need PSD files.

Support site URL: https://www.pearlthemes.com/support/


